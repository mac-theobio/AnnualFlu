## Indexed by month (not flumonth).  1 for winter, two for summer.

main   = c(1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1)
swin   = c(1, 1, 1, 0, 2, 2, 2, 2, 2, 2, 0, 1)
short  = c(1, 1, 1, 0, 0, 2, 2, 2, 2, 0, 0, 1)
ssum   = c(1, 1, 1, 1, 0, 2, 2, 2, 2, 0, 1, 1)
broad  = c(1, 1, 1, 1, 2, 2, 0, 0, 2, 2, 1, 1)
base   = c(1, 1, 1, 2, 2, 0, 0, 0, 0, 2, 2, 1)
