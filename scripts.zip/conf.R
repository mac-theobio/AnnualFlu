confprint(mainlinmod$tot$multpi, vnames)
confprint(mainlinmod$tot$other, vnames)
confprint(mainlinmod$tot$multrc, vnames)
confprint(mainlinmod$tot$non, vnames)
confprint(mainlinmod$tot$all, vnames)

