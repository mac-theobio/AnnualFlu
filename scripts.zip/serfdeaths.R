serf = read.table("serfling.txt", header=TRUE)

